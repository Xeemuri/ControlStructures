#include <iostream>
#include <conio.h>
using namespace std;
int main() {
	setlocale(LC_ALL, "Russian");
	do
	{
		char key = _getch();
        if (key == 119 || key == 87 || key == 72) {
            cout << "�����\n";
        }
        else if (key == 97 || key == 65 || key == 75) {
            cout << "������\n";
        }
        else if (key == 115 || key == 83 || key == 80) {
            cout << "�����\n";
        }
        else if (key == 100 || key == 68 || key == 77) {
            cout << "�������\n";
        }
        else if (key == 32) {
            cout << "������\n";
        }
        else if (key == 13) {
            cout << "�����!\n";
        }
        else if (key == 27) {
            cout << "�����...";
            return 0;
        }
	} while (true);
	return 0;
}